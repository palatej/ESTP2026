# camplet

A pure R implementation of **CAMPLET**, a transparent, adaptive seasonal
adjustment method that corrects for seasonality and outliers via
arithmetic-progression updates, without model identification or
optimisation.

Ported from the original VBA macro (`D200603-CampletExcel-v4.2`,
`basCBFherzien.bas`) and validated against its own output (see
`tests/testthat/test-camplet.R`). A Java port for JDemetra+ v3 lives at
[jdplus-camplet](../jdplus-camplet); this package has no dependency on it or
on Java.

## Installation

```r
# from source, until on CRAN
install.packages("remotes")
remotes::install_local("path/to/camplet-r")
```

## Usage

```r
library(camplet)

res <- camplet(AirPassengers)
res$accuracy
head(as.data.frame(res))
```

`camplet()` is univariate: one series in, one result out. To adjust many
series, loop over them yourself (e.g. `lapply()`/`purrr::map()` over a list
of series, or `dplyr::group_by() |> group_modify()` on a long data frame) -
the same way you would with `seasonal::seas()` or `stats::stl()`.

The returned object's `$data` has `raw`/`sa`/`seasonal` columns; `$diagnostics`
(or `as.data.frame(res, diagnostics = TRUE)`, the default) adds the
per-period adaptive-parameter trace that the original VBA tool wrote to its
"Adj_" worksheets (`ca`, `mu`, `pa`, `le`, `ti`, `expo_e`, `abs_pct_e`,
`years`, `weight`, `growth`).
